@props([
    'title' => null,
    'subtitle' => null,
    'showLogo' => true,
])

<div
    {{ $attributes->merge([
        'class' =>
            'rounded-2xl border border-slate-200/90 bg-white/95 p-8 shadow-[0_1px_0_rgba(255,255,255,0.75)_inset,0_24px_48px_-16px_rgba(15,23,42,0.18)] ring-1 ring-slate-900/[0.04] backdrop-blur-sm dark:border-white/[0.08] dark:bg-slate-900/80 dark:shadow-[0_1px_0_rgba(255,255,255,0.04)_inset,0_24px_48px_-16px_rgba(0,0,0,0.55)] dark:ring-white/[0.06] sm:p-10',
    ]) }}
>
    @if ($showLogo)
        <div class="mb-8 flex justify-center">
            <a
                href="{{ route('home') }}"
                class="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 shadow-lg shadow-indigo-500/30 ring-1 ring-white/20 transition-transform hover:scale-[1.02]"
            >
                <x-application-logo class="h-7 w-7 text-white" />
            </a>
        </div>
    @endif

    @if ($title || $subtitle)
        <header class="mb-8 text-center">
            @if ($title)
                <h2 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-white">
                    {{ $title }}
                </h2>
            @endif
            @if ($subtitle)
                <p class="mt-2 text-sm leading-relaxed text-slate-500 dark:text-slate-400">
                    {{ $subtitle }}
                </p>
            @endif
        </header>
    @endif

    {{ $slot }}
</div>
