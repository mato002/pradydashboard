<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            LicenseModuleSeeder::class,
            BackupDemoSeeder::class,
            SslDomainDemoSeeder::class,
            SubscriptionDemoSeeder::class,
            InvoiceDemoSeeder::class,
            AccessControlDemoSeeder::class,
            DeploymentDemoSeeder::class,
        ]);

        User::query()->firstOrCreate(
            ['email' => 'admin@pradytecai.test'],
            [
                'name' => 'Prady Admin',
                'password' => Hash::make('password'),
                'email_verified_at' => now(),
            ]
        );
    }
}
