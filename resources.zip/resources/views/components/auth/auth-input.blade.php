@props([
    'label',
    'name',
    'id' => null,
    'type' => 'text',
    'autocomplete' => null,
    'value' => null,
    'revealable' => false,
    'required' => false,
    'autofocus' => false,
    'readonly' => false,
    'placeholder' => '',
])

@php
    $id = $id ?? $name;
    $messages = $errors->get($name);
    $isPassword = $type === 'password' && $revealable;
    $iconPadding = isset($icon) ? 'pl-11' : 'pl-4';
    $readOnlyClass = $readonly
        ? 'cursor-not-allowed bg-slate-50/90 text-slate-600 dark:bg-slate-900/60 dark:text-slate-300'
        : '';
@endphp

<div @class(['space-y-1.5', $attributes->get('class')])>
    <label for="{{ $id }}" class="block text-sm font-medium text-slate-700 dark:text-slate-200">
        {{ $label }}
    </label>

    @if ($isPassword)
        <div x-data="{ show: false }" class="relative">
            @isset($icon)
                <span
                    class="pointer-events-none absolute inset-y-0 left-0 z-[1] flex w-11 items-center justify-center text-slate-400 dark:text-slate-500"
                >
                    {{ $icon }}
                </span>
            @endisset
            <input
                :type="show ? 'text' : 'password'"
                name="{{ $name }}"
                id="{{ $id }}"
                @if ($value !== null) value="{{ $value }}" @endif
                @if ($autocomplete) autocomplete="{{ $autocomplete }}" @endif
                @required($required)
                @if ($readonly) readonly @endif
                @autofocus($autofocus)
                placeholder="{{ $placeholder }}"
                class="{{ $iconPadding }} pr-12 block h-12 w-full rounded-xl border border-slate-200/90 bg-white text-sm text-slate-900 shadow-sm transition placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/15 dark:border-white/10 dark:bg-slate-950/50 dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-400/20 {{ $readOnlyClass }}"
                {{ $attributes->except('class') }}
            />
            <button
                type="button"
                class="absolute inset-y-0 right-0 flex w-11 items-center justify-center rounded-r-xl text-slate-400 transition hover:text-slate-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 dark:text-slate-500 dark:hover:text-slate-300"
                @click="show = !show"
                :aria-pressed="show"
                tabindex="-1"
            >
                <span x-show="!show">
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                    </svg>
                </span>
                <span x-show="show" x-cloak>
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" />
                    </svg>
                </span>
                <span class="sr-only">{{ __('Toggle password visibility') }}</span>
            </button>
        </div>
    @else
        <div class="relative">
            @isset($icon)
                <span
                    class="pointer-events-none absolute inset-y-0 left-0 flex w-11 items-center justify-center text-slate-400 dark:text-slate-500"
                >
                    {{ $icon }}
                </span>
            @endisset
            <input
                name="{{ $name }}"
                id="{{ $id }}"
                type="{{ $type }}"
                @if ($value !== null) value="{{ $value }}" @endif
                @if ($autocomplete) autocomplete="{{ $autocomplete }}" @endif
                @required($required)
                @if ($readonly) readonly @endif
                @autofocus($autofocus)
                placeholder="{{ $placeholder }}"
                class="{{ $iconPadding }} pr-4 block h-12 w-full rounded-xl border border-slate-200/90 bg-white text-sm text-slate-900 shadow-sm transition placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/15 dark:border-white/10 dark:bg-slate-950/50 dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-400/20 {{ $readOnlyClass }}"
                {{ $attributes->except('class') }}
            />
        </div>
    @endif

    <x-input-error :messages="$messages" class="mt-1.5" />
</div>
