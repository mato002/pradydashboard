<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="h-full scroll-smooth">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }} — {{ __('Enterprise control plane') }}</title>

        <script>
            (function () {
                try {
                    var t = localStorage.getItem('prady-theme') || 'light';
                    var dark = t === 'dark' || (t === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
                    document.documentElement.classList.toggle('dark', dark);
                } catch (e) {}
            })();
        </script>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />

        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body
        x-data="authShell()"
        class="min-h-[100dvh] min-h-screen bg-mesh-light font-sans text-slate-900 antialiased dark:bg-mesh-dark dark:text-slate-100"
    >
        <div
            class="fixed right-4 top-4 z-50 flex items-center gap-1 rounded-full border border-slate-200/80 bg-white/90 p-1 shadow-lg backdrop-blur-md dark:border-white/10 dark:bg-slate-900/90"
            aria-label="{{ __('Theme') }}"
        >
            <button
                type="button"
                class="rounded-full px-2.5 py-1.5 text-xs font-medium transition-colors hover:bg-slate-100 dark:hover:bg-slate-800"
                :class="theme === 'light' ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-200' : 'text-slate-500 dark:text-slate-400'"
                @click="setTheme('light')"
                title="{{ __('Light') }}"
            >
                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-4.773-4.227-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" />
                </svg>
            </button>
            <button
                type="button"
                class="rounded-full px-2.5 py-1.5 text-xs font-medium transition-colors hover:bg-slate-100 dark:hover:bg-slate-800"
                :class="theme === 'dark' ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-200' : 'text-slate-500 dark:text-slate-400'"
                @click="setTheme('dark')"
                title="{{ __('Dark') }}"
            >
                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 0 0 9.002-5.998Z" />
                </svg>
            </button>
            <button
                type="button"
                class="rounded-full px-2.5 py-1.5 text-xs font-medium transition-colors hover:bg-slate-100 dark:hover:bg-slate-800"
                :class="theme === 'system' ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-200' : 'text-slate-500 dark:text-slate-400'"
                @click="setTheme('system')"
                title="{{ __('System') }}"
            >
                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 17.25v1.007a3 3 0 0 1-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0 1 15 18.257V17.25m6-12V15a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 15V5.25m18 0A2.25 2.25 0 0 0 18.75 3H5.25A2.25 2.25 0 0 0 3 5.25m18 0V12a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 12V5.25" />
                </svg>
            </button>
        </div>

        <header
            class="sticky top-0 z-40 border-b border-slate-200/80 bg-white/80 backdrop-blur-xl dark:border-slate-800/80 dark:bg-slate-950/75"
        >
            <div class="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
                <a href="{{ route('home') }}" class="flex items-center gap-2.5 text-slate-900 transition hover:opacity-90 dark:text-white">
                    <span
                        class="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-sm font-bold text-white shadow-md"
                    >
                        P
                    </span>
                    <span class="text-sm font-semibold tracking-tight">{{ config('app.name', 'Prady Dashboard') }}</span>
                </a>
                <nav class="flex items-center gap-2 text-xs font-semibold sm:gap-3 sm:text-sm">
                    @auth
                        <a
                            href="{{ route('dashboard') }}"
                            class="rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 px-3 py-2 text-white shadow-sm transition hover:brightness-110"
                        >
                            {{ __('Dashboard') }}
                        </a>
                    @else
                        @if (Route::has('login'))
                            <a
                                href="{{ route('login') }}"
                                class="rounded-lg px-3 py-2 text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
                            >
                                {{ __('Log in') }}
                            </a>
                        @endif
                        @if (Route::has('register'))
                            <a
                                href="{{ route('register') }}"
                                class="rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 px-3 py-2 text-white shadow-sm transition hover:brightness-110"
                            >
                                {{ __('Get started') }}
                            </a>
                        @endif
                    @endauth
                </nav>
            </div>
        </header>

        <main>
            <section class="relative overflow-hidden border-b border-slate-200/80 dark:border-slate-800/80">
                <div
                    class="pointer-events-none absolute inset-0 bg-gradient-to-b from-indigo-500/[0.07] via-transparent to-transparent dark:from-indigo-500/10"
                    aria-hidden="true"
                ></div>
                <div class="relative mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8 lg:py-28">
                    <p class="text-[11px] font-semibold uppercase tracking-[0.28em] text-indigo-600 dark:text-indigo-300">
                        {{ __('PradytecAI') }}
                    </p>
                    <h1 class="mt-4 max-w-3xl text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl lg:text-5xl dark:text-white">
                        {{ __('One control plane for tenants, infrastructure, and billing.') }}
                    </h1>
                    <p class="mt-6 max-w-2xl text-base leading-relaxed text-slate-600 dark:text-slate-400">
                        {{ __('Operate servers, hosted projects, licensing, monitoring, and deployments from a single premium workspace built for SaaS teams.') }}
                    </p>
                    <div class="mt-10 flex flex-wrap items-center gap-3">
                        @auth
                            <a
                                href="{{ route('dashboard') }}"
                                class="inline-flex items-center justify-center rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:brightness-110"
                            >
                                {{ __('Open dashboard') }}
                            </a>
                        @else
                            @if (Route::has('register'))
                                <a
                                    href="{{ route('register') }}"
                                    class="inline-flex items-center justify-center rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:brightness-110"
                                >
                                    {{ __('Create account') }}
                                </a>
                            @endif
                            @if (Route::has('login'))
                                <a
                                    href="{{ route('login') }}"
                                    class="inline-flex items-center justify-center rounded-xl border border-slate-200/90 bg-white/80 px-6 py-3 text-sm font-semibold text-slate-800 shadow-sm backdrop-blur transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-100 dark:hover:bg-slate-800"
                                >
                                    {{ __('Sign in') }}
                                </a>
                            @endif
                        @endauth
                    </div>
                </div>
            </section>

            <section class="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
                <h2 class="text-center text-xs font-semibold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-300">
                    {{ __('Platform') }}
                </h2>
                <p class="mx-auto mt-3 max-w-2xl text-center text-lg font-semibold tracking-tight text-slate-900 dark:text-white">
                    {{ __('Everything you expect from an enterprise SaaS back office.') }}
                </p>
                <div class="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    @foreach (
                        [
                            [
                                'title' => __('Tenant lifecycle'),
                                'body' => __('Provision tenants, modules, and access from one place with clear audit trails.'),
                            ],
                            [
                                'title' => __('Infrastructure visibility'),
                                'body' => __('Health signals, capacity, and incidents surfaced for operators—not spreadsheets.'),
                            ],
                            [
                                'title' => __('Billing & licensing'),
                                'body' => __('Subscriptions, invoices, and license APIs aligned so finance and engineering stay in sync.'),
                            ],
                        ] as $card
                    )
                        <div
                            class="rounded-2xl border border-slate-200/90 bg-white/90 p-6 shadow-card dark:border-slate-800/80 dark:bg-slate-900/50 dark:shadow-none"
                        >
                            <h3 class="text-sm font-semibold text-slate-900 dark:text-white">{{ $card['title'] }}</h3>
                            <p class="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{{ $card['body'] }}</p>
                        </div>
                    @endforeach
                </div>
            </section>

            <section
                class="border-y border-slate-200/80 bg-white/60 py-14 dark:border-slate-800/80 dark:bg-slate-950/40 sm:py-16"
            >
                <div class="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
                    <div class="grid gap-10 lg:grid-cols-2 lg:items-center">
                        <div>
                            <h2 class="text-2xl font-semibold tracking-tight text-slate-900 dark:text-white">
                                {{ __('Ready when your team is.') }}
                            </h2>
                            <p class="mt-4 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
                                {{ __('Use Prady Dashboard as your internal operations hub, or extend it with modules as your product surface grows.') }}
                            </p>
                            <ul class="mt-8 space-y-3 text-sm text-slate-700 dark:text-slate-300">
                                @foreach (
                                    [
                                        __('Role-aware navigation and placeholders for every admin section'),
                                        __('Dark mode and dense tables tuned for long sessions'),
                                        __('Consistent Prady shell across auth and the authenticated app'),
                                    ] as $item
                                )
                                    <li class="flex gap-3">
                                        <span
                                            class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-600 ring-1 ring-emerald-500/25 dark:text-emerald-300"
                                        >
                                            <svg class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                                            </svg>
                                        </span>
                                        <span>{{ $item }}</span>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                        <div
                            class="rounded-2xl border border-slate-200/90 bg-mesh-light p-6 shadow-card dark:border-slate-800/80 dark:bg-slate-900/60"
                        >
                            <p class="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                                {{ __('Snapshot') }}
                            </p>
                            <p class="mt-1 text-sm font-medium text-slate-900 dark:text-white">{{ __('Operational posture') }}</p>
                            <div class="mt-6 grid grid-cols-3 gap-3">
                                <div class="rounded-xl border border-slate-200/80 bg-white/80 px-3 py-3 dark:border-slate-700 dark:bg-slate-950/50">
                                    <p class="text-[10px] font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
                                        {{ __('Regions') }}
                                    </p>
                                    <p class="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-white">12</p>
                                </div>
                                <div class="rounded-xl border border-slate-200/80 bg-white/80 px-3 py-3 dark:border-slate-700 dark:bg-slate-950/50">
                                    <p class="text-[10px] font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
                                        {{ __('Uptime') }}
                                    </p>
                                    <p class="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-white">99.97%</p>
                                </div>
                                <div class="rounded-xl border border-slate-200/80 bg-white/80 px-3 py-3 dark:border-slate-700 dark:bg-slate-950/50">
                                    <p class="text-[10px] font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
                                        {{ __('Tenants') }}
                                    </p>
                                    <p class="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-white">2.4k</p>
                                </div>
                            </div>
                            <p class="mt-6 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
                                {{ __('Figures shown for illustration; wire your own metrics from the dashboard.') }}
                            </p>
                        </div>
                    </div>
                </div>
            </section>
        </main>

        <footer class="border-t border-slate-200/80 bg-white/80 py-8 text-center text-xs text-slate-500 backdrop-blur dark:border-slate-800/80 dark:bg-slate-950/80 dark:text-slate-400">
            <p>© {{ now()->year }} PradytecAI · {{ __('All rights reserved.') }}</p>
            <p class="mt-1 tabular-nums">{{ __('Version') }} {{ config('app.version', '1.0.0') }}</p>
        </footer>
    </body>
</html>
